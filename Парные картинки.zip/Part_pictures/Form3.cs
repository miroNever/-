﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Part_pictures
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        Form4 f4 = new Form4();
        private void button1_Click(object sender, EventArgs e)
        {
           List<string> adm = new List<string>();
            StreamReader sr = File.OpenText("admin.txt");
            while (!sr.EndOfStream)
            {
                adm.Add(sr.ReadLine());
            }
            sr.Close();
            string error = "";
            if (adm[0] != textBox1.Text)
            {
                error += "Логин введён неверно\n";
            }
            if (adm[1] != textBox2.Text)
            {
                error += "Пароль введён неверно";
            }
            if (error == "")
            {
                f4.ShowDialog();
                textBox1.Text = "";
                textBox2.Text = "";
            }
            else
            {
                MessageBox.Show(error, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
