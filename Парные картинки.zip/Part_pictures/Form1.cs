namespace Part_pictures
{
    public partial class Form1 : Form
    {
        SingIn singin = new SingIn();
        Random r = new Random();
        List<string> icons = new List<string>();
        List<string> easy = new List<string>()
        {
            "!", "!", "N", "N", ",", ","
        };
        List<string> avarege = new List<string>()
        {
            "!", "!", "N", "N", ",", ",", "k", "k","b", "b", "v", "v", "w", "w", "z", "z"
        }; 
        List<string> hard = new List<string>()
        {
            "!", "!", "N", "N", ",", ",", "k", "k","b", "b", "v", "v", "w", "w", "z", "z", "+", "+", "$", "$"
        };
        Label firstClicked = null;
        Label secondClicked = null;


        private void AssignIconsToSquares()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = r.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icons.RemoveAt(randomNumber);
                }
            }
        }
        int count = 0;
        public Form1()
        {
            InitializeComponent();
            singin.ShowDialog();
            if (singin.complexity == "������") Create_table(2, 3, easy);
            else if (singin.complexity == "�������") Create_table(4, 4, avarege);
            else if (singin.complexity == "�������") Create_table(4, 5, hard);
        }
        List<Label> cells = new List<Label>();
        Panel panel = new Panel();
        TableLayoutPanel table = new TableLayoutPanel();
        private void Create_table(int Columns, int Rows, List<string> icon)
        {
            panel.Controls.Clear();
            table.Dock = DockStyle.Fill;
            table.BackColor = Color.CornflowerBlue;

            panel.Width = Convert.ToInt32(this.Width * 0.976f);
            panel.Height = Convert.ToInt32(this.Height * 0.938f);

            //�������
            table.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            table.Location = new System.Drawing.Point(0, 0);
            table.Visible = true;
            table.ColumnCount = Convert.ToInt32(Columns);
            table.RowCount = Convert.ToInt32(Rows);

            int width = 100 / table.ColumnCount;
            int height = 100 / table.RowCount;
            table.Font = new Font("Webdings", 48);
            // ��������� ������� � ������
            for (int col = 0; col < table.ColumnCount; col++)
            {
                // ��������� �������
                table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));

                for (int row = 0; row < table.RowCount; row++)
                {
                    // ��������� ������
                    if (col == 0)
                    {
                        table.RowStyles.Add(new RowStyle(SizeType.Percent, height));
                    }
                    var label = new Label();
                    label.Click += label1_Click;
                    label.AutoSize = false;
                    label.Font = new Font("Webdings", 48);
                    label.Name = ("label" + row + col).ToString();
                    label.Text = '�'.ToString();
                    label.Dock = DockStyle.Fill;
                    label.TextAlign = ContentAlignment.MiddleCenter;
                    table.Controls.Add(label, col, row);
                }
            }
            Controls.Add(panel);
            panel.Controls.Add(table);
            foreach (Control control in table.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = r.Next(icon.Count);
                    iconLabel.Text = icon[randomNumber];
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icon.RemoveAt(randomNumber);
                }
            }
            table.AutoSize = true;
            table.Dock = DockStyle.Fill;
        }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
                return;
            Label clickedLabel = sender as Label;
            if (clickedLabel != null)
            {
                if (clickedLabel.ForeColor == Color.Black)
                    return;
                if (firstClicked == null)
                {
                    singin.count++;
                    firstClicked = clickedLabel;
                    firstClicked.ForeColor = Color.Black;
                    return;
                }
                secondClicked = clickedLabel;
                secondClicked.ForeColor = Color.Black;
                CheckForWinner();
                if (firstClicked.Text == secondClicked.Text)
                {
                    
                    firstClicked = null;
                    secondClicked = null;
                    return;
                }
                timer1.Start();
            }
        }
        private void CheckForWinner()
        {
            foreach (Control control in table.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor)
                        return;
                }
            }
            
            MessageBox.Show($"�� ����������� ��� ������ �� {singin.count} �����!", "������������");
            StreamWriter sw = File.AppendText("file.txt");
            sw.WriteLine($"{singin.name} {singin.complexity} {singin.count}");
            sw.Close();
            singin.ShowDialog();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;
            firstClicked = null;
            secondClicked = null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}