﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Part_pictures
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.Columns.Add("Имя игрока", "Имя игрока");
            dataGridView1.Columns.Add("Сложность игры", "Сложность игры");
            dataGridView1.Columns.Add("Кол-во шагов", "Кол-во шагов");
            using (StreamReader sr = new StreamReader("file.txt"))
            { 
                string line;
                while ((line = sr.ReadLine()) != null)
                { 
                    string[] parts = line.Split(' ');
                    string name = parts[0];
                    string complexity = parts[1];
                    string steps = parts[2];
                    dataGridView1.Rows.Add(name, complexity, steps);
                }
            }
        }
    }
}
