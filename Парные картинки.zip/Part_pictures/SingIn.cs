﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Part_pictures
{
    public partial class SingIn : Form
    {
        public string name = "";
        public string complexity;
        public int count = 0;
        public SingIn()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == String.Empty)
            {
                MessageBox.Show("Введите имя пользователя");
            }
            else
            {
                if (radioButton1.Checked)
                {
                    complexity = radioButton1.Text;
                    Close();
                }
                else if (radioButton2.Checked)
                {
                    complexity = radioButton2.Text;
                    Close();
                }
                else if (radioButton3.Checked)
                {
                    complexity = radioButton3.Text;
                    Close();
                }
                name = textBox1.Text;
            }
        }
        private void SingIn_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }
    }
}
